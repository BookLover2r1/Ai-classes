# CS AI Workflow — Submission B

End-to-end AI workflow simulation for a B2B SaaS Customer Success function.
Covers all seven operating areas using the provided synthetic dataset.

## Requirements

- Python 3.10+
- No external libraries required (uses only stdlib)
- Optional: `ANTHROPIC_API_KEY` environment variable for live Claude API calls

## Setup

```bash
cd cs_workflow
# No pip install needed — stdlib only
```

## Run the workflow

### Single run (mock mode — no API key needed)
```bash
python run_workflow.py --mock
```

### Single run with a specific run ID
```bash
python run_workflow.py --run-id 3 --mock
```

### All 5 representative runs (mock mode)
```bash
python run_workflow.py --all-runs --mock
```

### Live mode (requires ANTHROPIC_API_KEY)
```bash
export ANTHROPIC_API_KEY=sk-ant-...
python run_workflow.py --all-runs
```

## Output

Each run saves a full JSON report to `outputs/runs/run_NN.json` containing:
- All stage results (account review, prioritization, triage, check-in briefs, QA scores, intervention plans, routing decisions)
- Token counts and cost per stage
- Total run cost and projected annual cost

Aggregate stats across all 5 runs are saved to `logs/aggregate_summary.json`.

## Project structure

```
cs_workflow/
├── run_workflow.py          # Single entry point
├── workflow/
│   ├── __init__.py
│   ├── data_loader.py       # CSV data loading
│   ├── claude_client.py     # Claude API + mock responses
│   ├── token_logger.py      # Token & cost tracking
│   ├── stages.py            # All 7 workflow stages + prompts
│   └── report.py            # Run output saving
├── data/                    # Synthetic dataset (provided)
│   ├── accounts.csv
│   ├── usage_events.csv
│   ├── support_tickets.csv
│   ├── call_notes.csv
│   ├── scheduled_checkins.csv
│   ├── junior_outputs.csv
│   └── quality_standards.csv
├── outputs/
│   └── runs/                # Saved run outputs (run_01.json … run_05.json)
├── logs/
│   └── aggregate_summary.json
└── README.md
```

## Workflow stages

| # | Stage | Model tier | Description |
|---|-------|-----------|-------------|
| 1 | Account Health Review | Low-cost | Reviews all 18 accounts against usage and health signals |
| 2 | Portfolio Prioritization | Mid | Ranks full portfolio into P1/P2/P3 with rationale |
| 3 | Inbound Issue Handling | Low-cost | Triages all 12 tickets to immediate/followup/escalate |
| 4 | Customer Check-in Support | Mid | Pre-meeting briefs + follow-up notes for 12 check-ins |
| 5 | Output Quality Review | Mid | Reviews 8 junior outputs against 6 quality standards |
| 6 | Intervention Planning | High-reasoning | Designs corrective plans for declining account segments |
| 7 | Routing & Escalation | Low-cost / High | Final routing decisions + escalation packets |

## Pricing tiers used

From the Token Math Sheet template:
- Low-cost model: $0.15/M input, $0.60/M output
- Mid model: $0.80/M input, $3.20/M output
- High-reasoning model: $3.00/M input, $12.00/M output
- Embedding/retrieval: $0.10/M input, $0.00/M output

## Token budget

Annual budget: $50,000/year
Projected annual cost at stated volumes: ~$1,200–1,500/year
Budget headroom: >97% — design supports significant volume scaling
