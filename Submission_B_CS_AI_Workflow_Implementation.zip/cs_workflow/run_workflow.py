#!/usr/bin/env python3
"""
Customer Success AI Workflow
Single entry point: python run_workflow.py [--run-id N] [--mock]
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

from workflow.data_loader import DataLoader
from workflow.stages import (
    AccountReviewStage,
    PrioritizationStage,
    InboundIssueStage,
    CheckinSupportStage,
    QualityReviewStage,
    InterventionPlanningStage,
    RoutingEscalationStage,
)
from workflow.token_logger import TokenLogger
from workflow.report import save_run_report


def run_workflow(run_id: int, mock: bool = False):
    print(f"\n{'='*60}")
    print(f"  CS AI Workflow — Run #{run_id}  |  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Mode: {'MOCK (no API calls)' if mock else 'LIVE (Claude API)'}")
    print(f"{'='*60}\n")

    loader = DataLoader("data")
    logger = TokenLogger(run_id)

    # Load all data
    accounts      = loader.accounts()
    usage         = loader.usage_events()
    tickets       = loader.support_tickets()
    call_notes    = loader.call_notes()
    checkins      = loader.scheduled_checkins()
    outputs       = loader.junior_outputs()
    standards     = loader.quality_standards()

    results = {}

    # ── Stage 1: Account Review ──────────────────────────────────────────────
    print("▶ Stage 1: Account Health Review")
    stage1 = AccountReviewStage(logger, mock=mock)
    results["account_review"] = stage1.run(accounts, usage)
    print(f"  ✓ {len(results['account_review'])} accounts reviewed\n")

    # ── Stage 2: Prioritization ──────────────────────────────────────────────
    print("▶ Stage 2: Portfolio Prioritization")
    stage2 = PrioritizationStage(logger, mock=mock)
    results["prioritization"] = stage2.run(results["account_review"])
    print(f"  ✓ Priority list generated — "
          f"P1:{sum(1 for a in results['prioritization'] if a['priority']=='P1')} "
          f"P2:{sum(1 for a in results['prioritization'] if a['priority']=='P2')} "
          f"P3:{sum(1 for a in results['prioritization'] if a['priority']=='P3')}\n")

    # ── Stage 3: Inbound Issue Handling ─────────────────────────────────────
    print("▶ Stage 3: Inbound Issue Handling")
    stage3 = InboundIssueStage(logger, mock=mock)
    results["inbound_issues"] = stage3.run(tickets, accounts)
    print(f"  ✓ {len(results['inbound_issues'])} tickets triaged and routed\n")

    # ── Stage 4: Customer Check-in Support ──────────────────────────────────
    print("▶ Stage 4: Customer Check-in Support")
    stage4 = CheckinSupportStage(logger, mock=mock)
    results["checkin_support"] = stage4.run(checkins, accounts, call_notes, tickets)
    print(f"  ✓ {len(results['checkin_support'])} check-in briefs + follow-ups generated\n")

    # ── Stage 5: Output Quality Review ──────────────────────────────────────
    print("▶ Stage 5: Output Quality Review")
    stage5 = QualityReviewStage(logger, mock=mock)
    results["quality_review"] = stage5.run(outputs, standards, accounts)
    flagged = sum(1 for o in results["quality_review"] if o["overall_pass"] is False)
    print(f"  ✓ {len(results['quality_review'])} outputs reviewed — {flagged} flagged for revision\n")

    # ── Stage 6: Intervention Planning ──────────────────────────────────────
    print("▶ Stage 6: Targeted Intervention Planning")
    stage6 = InterventionPlanningStage(logger, mock=mock)
    results["interventions"] = stage6.run(results["prioritization"], usage, call_notes)
    print(f"  ✓ {len(results['interventions'])} intervention plans generated\n")

    # ── Stage 7: Routing & Escalation ───────────────────────────────────────
    print("▶ Stage 7: Routing & Escalation")
    stage7 = RoutingEscalationStage(logger, mock=mock)
    results["routing"] = stage7.run(results["inbound_issues"], results["prioritization"], tickets)
    escalated = sum(1 for r in results["routing"] if r["route"] == "escalate")
    print(f"  ✓ {len(results['routing'])} items routed — {escalated} escalated\n")

    # ── Summary ───────────────────────────────────────────────────────────────
    summary = logger.summary()
    print("=" * 60)
    print("  TOKEN & COST SUMMARY")
    print("=" * 60)
    for stage, data in summary["by_stage"].items():
        print(f"  {stage:<35} {data['total_tokens']:>6} tok   ${data['cost']:.5f}")
    print(f"  {'─'*55}")
    print(f"  {'TOTAL':<35} {summary['total_tokens']:>6} tok   ${summary['total_cost']:.5f}")
    print(f"  Projected annual cost (×260 days):        ${summary['total_cost']*260:.2f}")
    print("=" * 60)

    save_run_report(run_id, results, summary)
    print(f"\n  Output saved → outputs/runs/run_{run_id:02d}.json\n")
    return results, summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="CS AI Workflow")
    parser.add_argument("--run-id", type=int, default=1, help="Run identifier (1–5+)")
    parser.add_argument("--mock", action="store_true", help="Use mock responses (no API key needed)")
    parser.add_argument("--all-runs", action="store_true", help="Execute all 5 representative runs")
    args = parser.parse_args()

    if args.all_runs:
        print("\nExecuting all 5 representative runs...\n")
        all_summaries = []
        for i in range(1, 6):
            _, summary = run_workflow(run_id=i, mock=args.mock)
            all_summaries.append(summary)
            time.sleep(0.5)

        avg_cost = sum(s["total_cost"] for s in all_summaries) / len(all_summaries)
        avg_tokens = sum(s["total_tokens"] for s in all_summaries) / len(all_summaries)
        print(f"\n{'='*60}")
        print(f"  AGGREGATE ACROSS 5 RUNS")
        print(f"  Avg tokens per run:  {avg_tokens:.0f}")
        print(f"  Avg cost per run:    ${avg_cost:.5f}")
        print(f"  Projected annual:    ${avg_cost*260:.2f}")
        print(f"{'='*60}\n")

        with open("logs/aggregate_summary.json", "w") as f:
            json.dump({
                "runs": 5,
                "avg_tokens_per_run": avg_tokens,
                "avg_cost_per_run": avg_cost,
                "projected_annual_cost": avg_cost * 260,
                "all_summaries": all_summaries,
            }, f, indent=2)
        print("  Aggregate log saved → logs/aggregate_summary.json\n")
    else:
        run_workflow(run_id=args.run_id, mock=args.mock)
