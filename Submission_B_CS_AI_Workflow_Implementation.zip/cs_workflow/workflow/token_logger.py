"""
Token and cost logger for each workflow stage.
Pricing from the Token Math Sheet template:
  Low-cost model:        $0.15 input / $0.60 output per 1M tokens
  Mid model:             $0.80 input / $3.20 output per 1M tokens
  High-reasoning model:  $3.00 input / $12.00 output per 1M tokens
  Embedding/retrieval:   $0.10 input / $0.00 output per 1M tokens
"""

PRICING = {
    "low":       {"input": 0.15,  "output": 0.60},
    "mid":       {"input": 0.80,  "output": 3.20},
    "high":      {"input": 3.00,  "output": 12.00},
    "embedding": {"input": 0.10,  "output": 0.00},
}


def compute_cost(model_tier: str, input_tokens: int, output_tokens: int) -> float:
    p = PRICING[model_tier]
    return (input_tokens * p["input"] + output_tokens * p["output"]) / 1_000_000


class TokenLogger:
    def __init__(self, run_id: int):
        self.run_id = run_id
        self.entries = []

    def log(self, stage: str, model_tier: str, input_tokens: int, output_tokens: int, label: str = ""):
        cost = compute_cost(model_tier, input_tokens, output_tokens)
        entry = {
            "stage": stage,
            "model_tier": model_tier,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
            "cost": cost,
            "label": label,
        }
        self.entries.append(entry)
        return entry

    def summary(self) -> dict:
        by_stage = {}
        for e in self.entries:
            s = e["stage"]
            if s not in by_stage:
                by_stage[s] = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0, "cost": 0.0, "calls": 0}
            by_stage[s]["input_tokens"]  += e["input_tokens"]
            by_stage[s]["output_tokens"] += e["output_tokens"]
            by_stage[s]["total_tokens"]  += e["total_tokens"]
            by_stage[s]["cost"]          += e["cost"]
            by_stage[s]["calls"]         += 1

        total_tokens = sum(e["total_tokens"] for e in self.entries)
        total_cost   = sum(e["cost"]         for e in self.entries)

        return {
            "run_id": self.run_id,
            "by_stage": by_stage,
            "total_tokens": total_tokens,
            "total_cost": total_cost,
            "entries": self.entries,
        }
