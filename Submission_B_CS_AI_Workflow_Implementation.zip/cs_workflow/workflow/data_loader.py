import csv
from pathlib import Path


class DataLoader:
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)

    def _load(self, filename: str) -> list[dict]:
        path = self.data_dir / filename
        with open(path, newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))

    def accounts(self):
        return self._load("accounts.csv")

    def usage_events(self):
        return self._load("usage_events.csv")

    def support_tickets(self):
        return self._load("support_tickets.csv")

    def call_notes(self):
        return self._load("call_notes.csv")

    def scheduled_checkins(self):
        return self._load("scheduled_checkins.csv")

    def junior_outputs(self):
        return self._load("junior_outputs.csv")

    def quality_standards(self):
        return self._load("quality_standards.csv")
