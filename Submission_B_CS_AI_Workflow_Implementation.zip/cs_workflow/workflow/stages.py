"""
All seven workflow stages for the CS AI system.
Each stage uses the TokenLogger to record token usage and cost.
"""

import json
from workflow.claude_client import call_claude
from workflow.token_logger import TokenLogger


# ─── STAGE 1: Account Health Review ─────────────────────────────────────────

ACCOUNT_REVIEW_PROMPT = """You are an expert customer success analyst. Review the following account data and produce a structured health assessment.

Account: {account_name} ({account_id})
Segment: {segment} | Contract: ${contract_value} | Renewal: {renewal_date}
Health score: {current_health_score} (prev: {previous_health_score}) | NPS: {nps_score}
Usage trend: {product_usage_trend} | Support tickets (30d): {support_ticket_count_30d}
Expansion signal: {expansion_signal} | Last contact: {last_contact_date}
Notes: {notes}

Recent usage:
{usage_summary}

Respond in valid JSON with these exact keys:
- health_assessment: "growing" | "stable" | "declining" | "critical"
- risk_level: "low" | "medium" | "high" | "critical"
- key_risks: list of strings (max 3)
- opportunities: list of strings (max 2)
- recommended_action: one clear sentence
- confidence: "low" | "medium" | "high"
"""


class AccountReviewStage:
    def __init__(self, logger: TokenLogger, mock: bool = False):
        self.logger = logger
        self.mock = mock

    def run(self, accounts: list, usage_events: list) -> list:
        results = []
        for acc in accounts:
            usage_rows = [u for u in usage_events if u["account_id"] == acc["account_id"]]
            usage_summary = "\n".join(
                f"  {u['event_date']}: {u['active_users']} active users, {u['key_feature_users']} power users, trend={u['usage_trend']}"
                for u in usage_rows[-3:]
            ) or "  No usage data available"

            prompt = ACCOUNT_REVIEW_PROMPT.format(**acc, usage_summary=usage_summary)
            response, in_tok, out_tok = call_claude(prompt, "account_review", "low", mock=self.mock)

            self.logger.log("1_account_review", "low", in_tok, out_tok, f"Review {acc['account_id']}")

            try:
                parsed = json.loads(response)
            except Exception:
                parsed = {"health_assessment": "unknown", "risk_level": "unknown",
                          "key_risks": [], "opportunities": [], "recommended_action": response, "confidence": "low"}

            results.append({**acc, "ai_review": parsed})

        return results


# ─── STAGE 2: Portfolio Prioritization ──────────────────────────────────────

PRIORITIZATION_PROMPT = """You are a customer success operations analyst. Given the following account health summaries, produce a priority-ranked list for today's CSM attention.

Accounts to prioritize:
{accounts_summary}

Scoring guidance:
- P1 (act today): critical health, imminent renewal risk, executive escalation, high ARR
- P2 (monitor closely): declining trend, medium ARR, near-term renewal risk
- P3 (maintain): stable or growing, no immediate action required

Respond in valid JSON with a "priority_ranking" array. Each item must have:
- account_id
- priority: "P1" | "P2" | "P3"
- score: integer 1-100 (higher = more urgent)
- reason: one sentence explanation
"""


class PrioritizationStage:
    def __init__(self, logger: TokenLogger, mock: bool = False):
        self.logger = logger
        self.mock = mock

    def run(self, reviewed_accounts: list) -> list:
        summary_lines = []
        for acc in reviewed_accounts:
            r = acc.get("ai_review", {})
            summary_lines.append(
                f"- {acc['account_id']} | {acc['account_name']} | {acc['segment']} | "
                f"${acc['contract_value']} | renewal {acc['renewal_date']} | "
                f"health {acc['current_health_score']} | risk={r.get('risk_level','?')} | "
                f"trend={acc['product_usage_trend']} | tickets={acc['support_ticket_count_30d']}"
            )

        prompt = PRIORITIZATION_PROMPT.format(accounts_summary="\n".join(summary_lines))
        response, in_tok, out_tok = call_claude(prompt, "prioritization", "mid", mock=self.mock)
        self.logger.log("2_prioritization", "mid", in_tok, out_tok, "Full portfolio prioritization")

        try:
            parsed = json.loads(response)
            ranking = parsed.get("priority_ranking", [])
        except Exception:
            ranking = []

        # Merge priority back into account records
        priority_map = {r["account_id"]: r for r in ranking}
        result = []
        for acc in reviewed_accounts:
            p = priority_map.get(acc["account_id"], {"priority": "P3", "score": 0, "reason": "No data"})
            result.append({**acc, "priority": p["priority"], "priority_score": p["score"], "priority_reason": p["reason"]})

        result.sort(key=lambda x: -x["priority_score"])
        return result


# ─── STAGE 3: Inbound Issue Handling ─────────────────────────────────────────

TRIAGE_PROMPT = """You are a customer success triage specialist. Assess the following inbound support ticket and determine the correct routing.

Ticket: {ticket_id}
Account: {account_name} ({account_id}) | Segment: {segment} | ARR: ${contract_value} | Renewal: {renewal_date}
Issue: {issue_summary}
Severity: {severity} | Sentiment: {customer_sentiment}
Frontline notes: {frontline_notes}
Current account health: {current_health_score}/100 | Trend: {product_usage_trend}

Routing options:
- "immediate_resolution": fix can be provided directly now
- "scheduled_followup": needs CSM follow-up within 24-72h
- "escalate": requires engineering, product, or senior CS leadership

Respond in valid JSON with:
- route: one of the three options above
- severity_confirmed: "Low" | "Medium" | "High" | "Critical"
- rationale: 1-2 sentences
- recommended_action: specific next step
- sla_hours: integer
- owner: who handles this
"""


class InboundIssueStage:
    def __init__(self, logger: TokenLogger, mock: bool = False):
        self.logger = logger
        self.mock = mock

    def run(self, tickets: list, accounts: list) -> list:
        acc_map = {a["account_id"]: a for a in accounts}
        results = []

        for ticket in tickets:
            acc = acc_map.get(ticket["account_id"], {})
            prompt = TRIAGE_PROMPT.format(
                **ticket,
                account_name=acc.get("account_name", "Unknown"),
                segment=acc.get("segment", "Unknown"),
                contract_value=acc.get("contract_value", "0"),
                renewal_date=acc.get("renewal_date", "Unknown"),
                current_health_score=acc.get("current_health_score", "?"),
                product_usage_trend=acc.get("product_usage_trend", "?"),
            )
            response, in_tok, out_tok = call_claude(prompt, "inbound_triage", "low", mock=self.mock)
            self.logger.log("3_inbound_issues", "low", in_tok, out_tok, f"Triage {ticket['ticket_id']}")

            try:
                parsed = json.loads(response)
            except Exception:
                parsed = {"route": "scheduled_followup", "severity_confirmed": ticket["severity"],
                          "rationale": response, "recommended_action": "Review manually", "sla_hours": 24, "owner": "CSM"}

            results.append({**ticket, "triage": parsed})

        return results


# ─── STAGE 4: Customer Check-in Support ──────────────────────────────────────

CHECKIN_BRIEF_PROMPT = """You are a senior customer success manager. Prepare a pre-meeting brief for the following scheduled check-in.

Scheduled Check-in:
- Checkin ID: {checkin_id} | Account: {account_name} ({account_id})
- Date: {scheduled_date} | Type: {checkin_type} | Priority: {priority}
- Topics to cover: {topics_to_cover}

Account context:
- Health: {current_health_score}/100 (prev: {previous_health_score}) | ARR: ${contract_value}
- Renewal: {renewal_date} | Trend: {product_usage_trend} | NPS: {nps_score}
- Notes: {notes}

Prior conversation ({call_date}):
- Participants: {participants}
- Summary: {call_summary}
- Customer goal: {customer_goal}
- Blocker: {risk_or_blocker}
- Committed follow-ups: {follow_up_items}

Open tickets: {open_tickets}

Write a structured pre-meeting brief covering:
1. Current situation and key risks
2. Open follow-up items and their status
3. Suggested agenda
4. Recommended CSM actions and tone guidance
"""

CHECKIN_FOLLOWUP_PROMPT = """You are a senior customer success manager. Write a post-meeting follow-up note for internal records and customer communication.

Account: {account_name} ({account_id}) | Meeting type: {checkin_type} | Date: {scheduled_date}
Prior context: {call_summary}
Topics covered: {topics_to_cover}

Based on the account context and meeting type, write a structured follow-up note with:
1. Meeting outcome summary
2. Specific action items with owner and due date
3. Customer sentiment assessment
4. Risk level and any escalation triggers
5. Next check-in recommendation
"""


class CheckinSupportStage:
    def __init__(self, logger: TokenLogger, mock: bool = False):
        self.logger = logger
        self.mock = mock

    def run(self, checkins: list, accounts: list, call_notes: list, tickets: list) -> list:
        acc_map   = {a["account_id"]: a for a in accounts}
        notes_map = {n["account_id"]: n for n in call_notes}
        results = []

        for c in checkins:
            acc   = acc_map.get(c["account_id"], {})
            notes = notes_map.get(c["account_id"], {})
            open_tickets = [t["issue_summary"] for t in tickets if t["account_id"] == c["account_id"] and t["current_status"] in ("open","new")]

            # Pre-meeting brief
            brief_prompt = CHECKIN_BRIEF_PROMPT.format(
                **c,
                account_name=acc.get("account_name", "Unknown"),
                current_health_score=acc.get("current_health_score", "?"),
                previous_health_score=acc.get("previous_health_score", "?"),
                contract_value=acc.get("contract_value", "0"),
                renewal_date=acc.get("renewal_date", "?"),
                product_usage_trend=acc.get("product_usage_trend", "?"),
                nps_score=acc.get("nps_score", "?"),
                notes=acc.get("notes", ""),
                call_date=notes.get("call_date", "N/A"),
                participants=notes.get("participants", "N/A"),
                call_summary=notes.get("summary", "No prior notes"),
                customer_goal=notes.get("customer_goal", "N/A"),
                risk_or_blocker=notes.get("risk_or_blocker", "N/A"),
                follow_up_items=notes.get("follow_up_items", "None"),
                open_tickets="; ".join(open_tickets) if open_tickets else "None",
            )
            brief_resp, b_in, b_out = call_claude(brief_prompt, "checkin_brief", "mid", mock=self.mock)
            self.logger.log("4_checkin_support", "mid", b_in, b_out, f"Brief {c['checkin_id']}")

            # Follow-up note
            followup_prompt = CHECKIN_FOLLOWUP_PROMPT.format(
                **c,
                account_name=acc.get("account_name", "Unknown"),
                call_summary=notes.get("summary", "No prior notes"),
            )
            followup_resp, f_in, f_out = call_claude(followup_prompt, "checkin_followup", "mid", mock=self.mock)
            self.logger.log("4_checkin_support", "mid", f_in, f_out, f"Followup {c['checkin_id']}")

            results.append({
                "checkin_id": c["checkin_id"],
                "account_id": c["account_id"],
                "account_name": acc.get("account_name", "Unknown"),
                "scheduled_date": c["scheduled_date"],
                "checkin_type": c["checkin_type"],
                "pre_meeting_brief": brief_resp,
                "follow_up_note": followup_resp,
            })

        return results


# ─── STAGE 5: Output Quality Review ─────────────────────────────────────────

QUALITY_REVIEW_PROMPT = """You are a customer success quality reviewer. Evaluate the following draft output against the specified quality standards.

Account: {account_name} ({account_id}) | Output type: {output_type}
Intended action: {intended_customer_action}

Draft output:
"{draft_text}"

Quality standards to evaluate:
{standards_text}

For each standard ID listed in quality_standard_ids ({quality_standard_ids}), score the draft:
- pass: true or false
- score: 1-5
- feedback: one sentence

Respond in valid JSON with:
- output_id: "{output_id}"
- standard_scores: object keyed by standard ID
- overall_pass: true if all standards pass, else false
- overall_score: average of standard scores (float)
- revision_required: true | false
- revision_guidance: specific rewrite instructions if revision_required is true, else null
"""


class QualityReviewStage:
    def __init__(self, logger: TokenLogger, mock: bool = False):
        self.logger = logger
        self.mock = mock

    def run(self, outputs: list, standards: list, accounts: list) -> list:
        acc_map = {a["account_id"]: a for a in accounts}
        std_map = {s["standard_id"]: s for s in standards}
        results = []

        for out in outputs:
            acc = acc_map.get(out["account_id"], {})
            std_ids = out["quality_standard_ids"].split(";")
            standards_text = "\n".join(
                f"- {sid}: {std_map[sid]['standard_name']} — {std_map[sid]['description']}"
                for sid in std_ids if sid in std_map
            )

            prompt = QUALITY_REVIEW_PROMPT.format(
                **out,
                account_name=acc.get("account_name", "Unknown"),
                standards_text=standards_text,
            )
            response, in_tok, out_tok = call_claude(prompt, "quality_review", "mid", mock=self.mock)
            self.logger.log("5_quality_review", "mid", in_tok, out_tok, f"QA {out['output_id']}")

            try:
                parsed = json.loads(response)
            except Exception:
                parsed = {"output_id": out["output_id"], "overall_pass": None,
                          "overall_score": None, "revision_required": True,
                          "revision_guidance": "Manual review required", "standard_scores": {}}

            results.append({**out, **parsed})

        return results


# ─── STAGE 6: Targeted Intervention Planning ─────────────────────────────────

INTERVENTION_PROMPT = """You are a customer success strategist. Analyze the following at-risk account segment and design a targeted intervention.

At-risk segment summary:
{segment_summary}

Account details:
{account_details}

Usage patterns across segment:
{usage_patterns}

Prior call context:
{call_context}

Design a targeted intervention plan. Respond in valid JSON with:
- segment: name/description of the segment
- pattern: what declining pattern you detected
- affected_accounts: list of account IDs
- root_cause_hypothesis: most likely cause (1-2 sentences)
- intervention_plan:
    - immediate: list of immediate actions (within 48h)
    - short_term: list of 1-2 week actions
    - measurement: how to measure success
- expected_outcome: what improvement to expect
- confidence: "low" | "medium" | "high"
"""


class InterventionPlanningStage:
    def __init__(self, logger: TokenLogger, mock: bool = False):
        self.logger = logger
        self.mock = mock

    def run(self, prioritized: list, usage_events: list, call_notes: list) -> list:
        # Focus on P1 accounts for intervention planning
        p1_accounts = [a for a in prioritized if a["priority"] == "P1"]
        if not p1_accounts:
            return []

        # Group by segment for pattern detection
        from collections import defaultdict
        by_segment = defaultdict(list)
        for acc in prioritized:
            if acc["priority"] in ("P1", "P2"):
                by_segment[acc["segment"]].append(acc)

        results = []
        for segment, accounts in by_segment.items():
            if len(accounts) < 1:
                continue

            account_details = "\n".join(
                f"- {a['account_id']} | {a['account_name']} | health={a['current_health_score']} | "
                f"trend={a['product_usage_trend']} | tickets={a['support_ticket_count_30d']} | "
                f"reason={a.get('priority_reason','')}"
                for a in accounts
            )
            usage_patterns = "\n".join(
                f"- {u['account_id']} {u['event_date']}: {u['active_users']} users, trend={u['usage_trend']}, {u['notable_change']}"
                for u in usage_events
                if any(u["account_id"] == a["account_id"] for a in accounts)
            )
            notes_context = "\n".join(
                f"- {n['account_id']} ({n['call_date']}): {n['summary']} | blocker: {n['risk_or_blocker']}"
                for n in call_notes
                if any(n["account_id"] == a["account_id"] for a in accounts)
            )
            segment_summary = (
                f"{segment}: {len(accounts)} accounts at P1/P2 priority. "
                f"Avg health: {sum(int(a['current_health_score']) for a in accounts)//len(accounts)}. "
                f"Total ARR at risk: ${sum(int(a['contract_value']) for a in accounts):,}"
            )

            prompt = INTERVENTION_PROMPT.format(
                segment_summary=segment_summary,
                account_details=account_details,
                usage_patterns=usage_patterns or "No usage data",
                call_context=notes_context or "No call notes",
            )
            response, in_tok, out_tok = call_claude(prompt, "intervention", "high", mock=self.mock)
            self.logger.log("6_interventions", "high", in_tok, out_tok, f"Intervention plan: {segment}")

            try:
                parsed = json.loads(response)
            except Exception:
                parsed = {"segment": segment, "pattern": "See response", "affected_accounts": [],
                          "root_cause_hypothesis": response, "intervention_plan": {}, "confidence": "low"}

            results.append(parsed)

        return results


# ─── STAGE 7: Routing & Escalation ───────────────────────────────────────────

ROUTING_PROMPT = """You are a customer success escalation coordinator. Given the following triaged issue, produce a final routing decision and — if escalating — an escalation packet.

Ticket: {ticket_id} | Account: {account_name} ({account_id})
ARR: ${contract_value} | Renewal: {renewal_date} | Health: {current_health_score}
Issue: {issue_summary}
Triage result: route={triage_route}, severity={triage_severity}
Triage rationale: {triage_rationale}
Portfolio priority: {priority}

Respond in valid JSON with:
- ticket_id
- final_route: "immediate_resolution" | "scheduled_followup" | "escalate"
- escalation_level: "csm" | "cs_lead" | "engineering" | "engineering_and_cs_lead" | "executive" (use null if not escalating)
- escalation_packet: object with subject, summary, risk, requested_action, account_owner (null if not escalating)
"""


class RoutingEscalationStage:
    def __init__(self, logger: TokenLogger, mock: bool = False):
        self.logger = logger
        self.mock = mock

    def run(self, triaged_issues: list, prioritized: list, tickets: list) -> list:
        priority_map = {a["account_id"]: a for a in prioritized}
        results = []

        for issue in triaged_issues:
            acc_data   = priority_map.get(issue["account_id"], {})
            triage     = issue.get("triage", {})
            model_tier = "high" if triage.get("route") == "escalate" else "low"

            prompt = ROUTING_PROMPT.format(
                ticket_id=issue["ticket_id"],
                account_name=acc_data.get("account_name", "Unknown"),
                account_id=issue["account_id"],
                contract_value=acc_data.get("contract_value", "0"),
                renewal_date=acc_data.get("renewal_date", "Unknown"),
                current_health_score=acc_data.get("current_health_score", "?"),
                issue_summary=issue["issue_summary"],
                triage_route=triage.get("route", "unknown"),
                triage_severity=triage.get("severity_confirmed", "unknown"),
                triage_rationale=triage.get("rationale", ""),
                priority=acc_data.get("priority", "P3"),
            )
            response, in_tok, out_tok = call_claude(prompt, "routing", model_tier, mock=self.mock)
            self.logger.log("7_routing_escalation", model_tier, in_tok, out_tok, f"Route {issue['ticket_id']}")

            try:
                parsed = json.loads(response)
            except Exception:
                parsed = {"ticket_id": issue["ticket_id"], "final_route": triage.get("route", "scheduled_followup"),
                          "escalation_level": None, "escalation_packet": None}

            results.append({**issue, "route": parsed.get("final_route"), "routing_detail": parsed})

        return results
