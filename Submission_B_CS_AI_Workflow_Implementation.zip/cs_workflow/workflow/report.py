import json
import os
from datetime import datetime
from pathlib import Path


def save_run_report(run_id: int, results: dict, summary: dict):
    Path("outputs/runs").mkdir(parents=True, exist_ok=True)
    report = {
        "run_id": run_id,
        "timestamp": datetime.now().isoformat(),
        "token_summary": summary,
        "results": {
            "account_review": [
                {
                    "account_id": a["account_id"],
                    "account_name": a["account_name"],
                    "segment": a["segment"],
                    "health_score": a["current_health_score"],
                    "ai_review": a.get("ai_review", {}),
                }
                for a in results.get("account_review", [])
            ],
            "prioritization": [
                {
                    "account_id": a["account_id"],
                    "account_name": a["account_name"],
                    "priority": a.get("priority"),
                    "priority_score": a.get("priority_score"),
                    "priority_reason": a.get("priority_reason"),
                }
                for a in results.get("prioritization", [])
            ],
            "inbound_issues": [
                {
                    "ticket_id": t["ticket_id"],
                    "account_id": t["account_id"],
                    "issue_summary": t["issue_summary"],
                    "severity": t["severity"],
                    "triage": t.get("triage", {}),
                }
                for t in results.get("inbound_issues", [])
            ],
            "checkin_support": [
                {
                    "checkin_id": c["checkin_id"],
                    "account_id": c["account_id"],
                    "account_name": c["account_name"],
                    "checkin_type": c["checkin_type"],
                    "pre_meeting_brief": c["pre_meeting_brief"],
                    "follow_up_note": c["follow_up_note"],
                }
                for c in results.get("checkin_support", [])
            ],
            "quality_review": [
                {
                    "output_id": o["output_id"],
                    "account_id": o["account_id"],
                    "output_type": o["output_type"],
                    "overall_pass": o.get("overall_pass"),
                    "overall_score": o.get("overall_score"),
                    "revision_required": o.get("revision_required"),
                    "revision_guidance": o.get("revision_guidance"),
                    "standard_scores": o.get("standard_scores", {}),
                }
                for o in results.get("quality_review", [])
            ],
            "interventions": results.get("interventions", []),
            "routing": [
                {
                    "ticket_id": r["ticket_id"],
                    "account_id": r["account_id"],
                    "route": r.get("route"),
                    "routing_detail": r.get("routing_detail", {}),
                }
                for r in results.get("routing", [])
            ],
        },
    }
    path = f"outputs/runs/run_{run_id:02d}.json"
    with open(path, "w") as f:
        json.dump(report, f, indent=2)
    return path
