"""
Claude API client.
In mock mode, returns realistic pre-written responses for each stage
so the workflow runs end-to-end without an API key.
"""

import json
import os
import re


MOCK_RESPONSES = {
    "account_review": """{
  "health_assessment": "declining",
  "risk_level": "high",
  "key_risks": ["usage drop in core module", "upcoming renewal", "low NPS"],
  "opportunities": [],
  "recommended_action": "Immediate CSM outreach required. Schedule exec call within 48 hours.",
  "confidence": "high"
}""",
    "account_review_healthy": """{
  "health_assessment": "growing",
  "risk_level": "low",
  "key_risks": [],
  "opportunities": ["expansion into analytics team", "premium feature upsell"],
  "recommended_action": "Continue current cadence. Explore expansion opportunity.",
  "confidence": "high"
}""",
    "prioritization": """{
  "priority_ranking": [
    {"account_id": "A008", "priority": "P1", "score": 95, "reason": "High-value enterprise with severe implementation blockers and declining health. Renewal risk is critical."},
    {"account_id": "A014", "priority": "P1", "score": 91, "reason": "Renewal imminent in under 30 days. Mobile adoption failure and declining health are compounding risks."},
    {"account_id": "A017", "priority": "P1", "score": 88, "reason": "No champion, very low health, negative sentiment, and active disengagement."},
    {"account_id": "A005", "priority": "P1", "score": 85, "reason": "Enterprise renewal within 45 days. Exec sponsor has requested usage proof. Declining trend."},
    {"account_id": "A002", "priority": "P2", "score": 74, "reason": "High support volume with unresolved integration failures. Renewal within 60 days."},
    {"account_id": "A010", "priority": "P2", "score": 68, "reason": "Usage declining in two departments with increasing ticket volume."},
    {"account_id": "A004", "priority": "P2", "score": 62, "reason": "Champion departure creates ownership risk. Usage declining significantly."},
    {"account_id": "A001", "priority": "P2", "score": 58, "reason": "Reporting module adoption declining. Dashboard export issue unresolved."},
    {"account_id": "A012", "priority": "P3", "score": 44, "reason": "High ticket volume but usage stable. Mainly enablement issues."},
    {"account_id": "A016", "priority": "P3", "score": 38, "reason": "Flat usage, rising support volume but neutral sentiment."},
    {"account_id": "A015", "priority": "P3", "score": 35, "reason": "Strategic account with stable usage. Roadmap concern needs tracking."},
    {"account_id": "A009", "priority": "P3", "score": 22, "reason": "Small SMB, stable usage, routine support needs."},
    {"account_id": "A007", "priority": "P3", "score": 20, "reason": "Stable account with no identified risks."},
    {"account_id": "A006", "priority": "P3", "score": 18, "reason": "Growing account with expansion signal. Low risk."},
    {"account_id": "A011", "priority": "P3", "score": 15, "reason": "Growing health. Expansion interest. No immediate risk."},
    {"account_id": "A003", "priority": "P3", "score": 12, "reason": "Very healthy. Expansion discussion active."},
    {"account_id": "A013", "priority": "P3", "score": 8,  "reason": "Highest NPS in portfolio. Advocacy candidate."},
    {"account_id": "A018", "priority": "P3", "score": 5,  "reason": "Strong growth trajectory. Expansion in progress."}
  ]
}""",
    "inbound_triage": """{
  "route": "escalate",
  "severity_confirmed": "High",
  "rationale": "SSO failure is blocking all admin users from completing implementation. Executive sponsor directly involved. High renewal risk if not resolved in 48 hours.",
  "recommended_action": "Immediately escalate to engineering. CSM to send executive holding statement within 2 hours. Schedule recovery call.",
  "sla_hours": 4,
  "owner": "Engineering + CSM"
}""",
    "inbound_triage_low": """{
  "route": "scheduled_followup",
  "severity_confirmed": "Low",
  "rationale": "Enablement question. No outage or risk signals. Customer sentiment positive.",
  "recommended_action": "CSM to respond within 24 hours with relevant documentation or schedule a short training session.",
  "sla_hours": 24,
  "owner": "CSM"
}""",
    "checkin_brief": """**PRE-MEETING BRIEF**

**Account:** Harbor Insurance (A008)
**Meeting type:** Implementation Recovery
**Date:** 2026-05-04
**CSM:** Morgan Lee

**Current Situation:**
Health score has dropped from 66 to 48 over the past 30 days. Implementation is blocked by persistent SSO failures affecting all admin users. Executive sponsor (VP Ops) is directly involved and frustrated.

**Open Follow-up Items from Last Call (2026-04-17):**
- CSM committed to coordinate technical escalation for SSO — STATUS: In progress, unresolved
- Rollout timeline was to be confirmed — STATUS: Blocked pending SSO fix

**Key Risks:**
- Renewal at risk if implementation not recovered before June 12
- Executive confidence deteriorating with each unresolved week
- $240K ARR exposed

**Suggested Agenda:**
1. SSO resolution status update (engineering to attend if possible)
2. Revised rollout timeline with concrete milestones
3. Confidence-rebuilding: what does success look like for the exec sponsor?

**Recommended CSM Actions:**
- Open with acknowledgment of delay and accountability
- Bring engineering rep or written technical update
- Offer executive-level escalation path if SSO not resolved by May 7
- Do not overpromise timelines without engineering confirmation""",

    "checkin_followup": """**POST-MEETING FOLLOW-UP NOTE**

**Account:** Harbor Insurance (A008)
**Date:** 2026-05-04
**Participants:** Morgan Lee (CSM), VP Ops, Admin Lead

**Meeting Outcome:**
Customer confirmed SSO issue is their primary blocker. VP Ops expressed frustration but is willing to give until May 10 for resolution. Rollout cannot proceed until SSO is fixed.

**Action Items:**
| Owner | Action | Due |
|-------|--------|-----|
| Engineering | Deliver SSO root cause analysis | 2026-05-06 |
| Morgan Lee | Send written recovery plan to VP Ops | 2026-05-07 |
| Morgan Lee | Schedule May 10 check-in to confirm resolution | 2026-05-05 |

**Customer Sentiment:** Frustrated but engaged. Willing to continue if progress is visible.

**Risk Level:** HIGH — renewal June 12. Escalate to CS Lead if SSO unresolved by May 8.

**Next Check-in:** 2026-05-10""",

    "quality_review": """{
  "output_id": "O001",
  "standard_scores": {
    "QS001": {"pass": false, "score": 2, "feedback": "Output does not reference SSO failure, executive sponsor, or implementation recovery context. Generic reassurance only."},
    "QS002": {"pass": false, "score": 1, "feedback": "No concrete next steps, timeline, owner, or recovery plan provided."},
    "QS003": {"pass": false, "score": 2, "feedback": "Understates risk severity. Implementation block with executive involvement requires stronger urgency signal."},
    "QS005": {"pass": false, "score": 2, "feedback": "No escalation action indicated despite High severity and executive involvement."}
  },
  "overall_pass": false,
  "overall_score": 1.75,
  "revision_required": true,
  "revision_guidance": "Rewrite to: (1) name the SSO issue and acknowledge the delay, (2) state a concrete recovery timeline with engineering owner, (3) commit to next communication date, (4) confirm escalation path if unresolved. Tone should be accountable and executive-appropriate."
}""",
    "intervention": """{
  "segment": "Declining Mid-Market",
  "pattern": "Four Mid-Market accounts show simultaneous health score decline, rising ticket volume, and usage drops in reporting or integration modules over the past 30 days.",
  "affected_accounts": ["A001", "A010", "A014", "A016"],
  "root_cause_hypothesis": "Likely a combination of a recent product change affecting report exports and insufficient onboarding for new admin contacts after turnover.",
  "intervention_plan": {
    "immediate": [
      "Engineering to investigate report export data freshness issue across affected accounts",
      "CSM team to send targeted outreach to all four accounts within 48 hours"
    ],
    "short_term": [
      "Deploy updated onboarding sequence for new admins in Mid-Market segment",
      "Create segment-specific office-hours session for reporting and integration questions"
    ],
    "measurement": [
      "Track health score change at 14-day and 30-day marks",
      "Monitor ticket volume reduction in reporting category",
      "Survey NPS delta 30 days post-intervention"
    ]
  },
  "expected_outcome": "Health score stabilization within 14 days. Ticket reduction of 30% in reporting category within 30 days.",
  "confidence": "medium"
}""",
    "routing": """{
  "ticket_id": "T001",
  "final_route": "escalate",
  "escalation_level": "engineering_and_cs_lead",
  "escalation_packet": {
    "subject": "ESCALATION: Harbor Insurance SSO Implementation Block — $240K Renewal at Risk",
    "summary": "Enterprise account ($240K ARR, renewal June 12) has been blocked by persistent SSO failures for 2+ weeks. Executive sponsor (VP Ops) directly involved. Implementation cannot proceed. Immediate engineering resource required.",
    "risk": "Critical — renewal in 6 weeks with zero implementation progress",
    "requested_action": "Engineering lead response within 4 hours. Root cause analysis by May 6. CSM to send holding statement by EOD.",
    "account_owner": "Morgan Lee"
  }
}""",
}


def call_claude(prompt: str, stage: str, model_tier: str, mock: bool = False) -> tuple[str, int, int]:
    """
    Call Claude API or return mock response.
    Returns: (response_text, input_tokens, output_tokens)
    """
    if mock:
        return _mock_response(stage, prompt), _estimate_tokens(prompt), _mock_output_tokens(stage)

    import urllib.request
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY not set. Run with --mock for no-API mode.")

    model_map = {
        "low":       "claude-haiku-4-5-20251001",
        "mid":       "claude-sonnet-4-6",
        "high":      "claude-sonnet-4-6",
        "embedding": None,
    }
    model = model_map[model_tier]

    payload = json.dumps({
        "model": model,
        "max_tokens": 1024,
        "messages": [{"role": "user", "content": prompt}],
    }).encode()

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload,
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
    )
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read())

    text = data["content"][0]["text"]
    in_tok  = data["usage"]["input_tokens"]
    out_tok = data["usage"]["output_tokens"]
    return text, in_tok, out_tok


def _estimate_tokens(text: str) -> int:
    return max(1, len(text) // 4)


def _mock_output_tokens(stage: str) -> int:
    estimates = {
        "account_review": 120,
        "prioritization": 380,
        "inbound_triage": 140,
        "checkin_brief": 320,
        "checkin_followup": 280,
        "quality_review": 200,
        "intervention": 350,
        "routing": 220,
    }
    return estimates.get(stage, 200)


def _mock_response(stage: str, prompt: str) -> str:
    prompt_lower = prompt.lower()

    if stage == "account_review":
        if any(w in prompt_lower for w in ["growing", "high nps", "expansion"]):
            return MOCK_RESPONSES["account_review_healthy"]
        return MOCK_RESPONSES["account_review"]

    if stage == "inbound_triage":
        if any(w in prompt_lower for w in ["low", "positive", "enablement", "how-to"]):
            return MOCK_RESPONSES["inbound_triage_low"]
        return MOCK_RESPONSES["inbound_triage"]

    return MOCK_RESPONSES.get(stage, '{"result": "mock response", "status": "ok"}')
